package com.akih.matarak.data

data class ModelArticle (
    val title : String,
    val thumbnail : String,
    val content : String
)